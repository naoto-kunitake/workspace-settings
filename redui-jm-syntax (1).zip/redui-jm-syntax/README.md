![Redui-jm screenshot](https://raw.githubusercontent.com/juanmnl/redui-jm-theme/master/logo.png)

# Redui-jm Syntax Theme :coffee:

Your coffee is ready!!  

A nice aromatic coffee infused syntax theme for Atom and the ONE DARK UI theme  
:coffee: From the highlands of the Andes to your Atom editor :coffee:

## Screen

-- *Font: Fira Code* --

JSX/ES6 (babel)
![Redui-jm screenshot](https://raw.githubusercontent.com/juanmnl/redui-jm-theme/master/jsx.png)  

Scss  
![Redui-jm screenshot](https://raw.githubusercontent.com/juanmnl/redui-jm-theme/master/scss.png)  

Html
![Redui-jm screenshot](https://raw.githubusercontent.com/juanmnl/redui-jm-theme/master/html.png)

Open Atom Preferences > Install > Search *themes*: `redui-jm-syntax`,
then Install.

*You may need to reload Atom `Cmd+R` in between these steps.*
Activate the theme by selecting the Themes section of Preferences.
